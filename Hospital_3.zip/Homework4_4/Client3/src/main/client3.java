package main;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.text.*;
import java.util.*;
  
// Client class
public class client3
{
    public static void main(String[] args) throws IOException 
    {
        try
        {
            InetAddress ip = InetAddress.getByName("localhost");
            // establish the connection with server port
            Socket s = new Socket(ip, 5064);
            // obtaining input and out streams
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            String url = "jdbc:mysql://192.168.2.138:3306";
    	    String user = "GONZALO";
    	    String pass = "Gonzalo1!";
    	    Connection connection;
    	    connection = DriverManager.getConnection(url ,user, pass);
    	    Statement st = connection.createStatement();
    	    st.execute("USE MINISTRY_OF_HEALTH");
    	    st.execute("CREATE TABLE HOSPITAL3(NumCases int)");
    	    st.execute("INSERT INTO HOSPITAL3 VALUES(0)");
    	    int numCases = 0;
    	    double doublingTime = 0.1;
            // Infinite loop
            while (true) 
            {
                waitNewCase(numCases,doublingTime);
                dos.writeUTF("New Case!");
                PreparedStatement ps = connection.prepareStatement ("UPDATE HOSPITAL3 SET NumCases = ? WHERE NumCases = ?");
                ps.setInt(1,numCases+1);
                ps.setInt(2,numCases);
                ps.executeUpdate();
                numCases = numCases + 1;
                if (numCases >= 100000) {
                	System.out.println("Maximum number of cases reached. Closing connection");
                	dos.writeUTF("Maximum Cases Reached");
                	s.close();
                	break;
                }
                // printing date or time as requested by client
                String received = dis.readUTF();
                if (received.equals("Maximum Number of cases received")) {
                	System.out.println("Maximum number of cases reached. Closing Connection");
                	s.close();
                	break;
                }
                System.out.println(received);
                
            }
              
            // closing resources
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void waitNewCase ( int currentCases , double doublingTime )
    		throws InterruptedException {
		if ( currentCases == 0 ) { // Wait for the first case to occur
			// Generate a random timeout
			int timeToFirstCase = (int) (1000*Math.random()) ;
			// Wait . Thread . sleep (int ms) " sleeps " the thread for ms milliseconds
			Thread.sleep(timeToFirstCase) ;
			} 
		else {
			int timeToNewCase = (int) ( doublingTime *1000) / currentCases ;
			Thread.sleep(timeToNewCase) ;
    	}
    }
}

