package main;
import java.io.*;
import java.sql.*;
import java.net.*;

public class server 
{
	int NumCases = 0;
	static int TotalCases = 0;
    public static void main(String[] args) throws Exception 
    {
        // server is listening on port
        ServerSocket server = new ServerSocket(5064);
        // InetAddress ip = InetAddress.getByName("localhost");
        String url = "jdbc:mysql://192.168.2.138:3306";
	    String user = "GONZALO";
	    String pass = "Gonzalo1!";
	    Connection connection;
	    connection = DriverManager.getConnection(url ,user, pass);
	    Statement st = connection.createStatement();
	    st.execute("DROP DATABASE MINISTRY_OF_HEALTH");
	    st.execute("CREATE DATABASE MINISTRY_OF_HEALTH");
	    st.execute("USE MINISTRY_OF_HEALTH");
	    st.execute("CREATE TABLE TOTALCASES(NumCases int)");
	    st.execute("INSERT INTO TOTALCASES VALUES (0)");
        // running infinite loop for getting
        // client request
        while (true) 
        {
            Socket s = null;
              
            try 
            {
                // Socket accepting connections
                s = server.accept();
                System.out.println("A new client is connected : " + s);
                // Obtain communication flow data
                DataInputStream dis = new DataInputStream(s.getInputStream());
                DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                System.out.println("Assigning new thread for this hospital");
                // New Thread
                Thread thread = new ClientHandler(s, dis, dos,0,connection);
                // Start thread
                thread.start();
            }
            catch (Exception e){
                s.close();
                e.printStackTrace();
            }
        }
    } 
}
	// Threads called ClientHandler
	class ClientHandler extends Thread
	{
	    final DataInputStream dis;
	    final DataOutputStream dos;
	    final Socket s;
	    int numCases;
	    Connection conn;
	    // Constructor
	    public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos, int NumCases, Connection connection) 
	    {
	        this.s = s;
	        this.dis = dis;
	        this.dos = dos;
	        this.numCases = NumCases;
	        this.conn = connection;
	    }
	  
	    @Override
	    public void run() 
	    {
	        String received;
	        String toreturn;
	        while (true) 
	        {
	            try {
	                // receive the answer from client
	                received = dis.readUTF();
	                int ms = 10;
	                switch (received) {
	                	case "New Case!":
	                        numCases = numCases + 1;
	                        server.TotalCases = server.TotalCases + 1;
	                     // If we dont want to use transactions: Comment this part and uncomment the one below
	                        conn.setAutoCommit(false);
	                        Savepoint sp = conn.setSavepoint();
	                        Statement st = conn.createStatement();
	                        ResultSet rs = st.executeQuery("SELECT 1 FROM TOTALCASES");
	                        int ActualCases = rs.getInt(1);
	                        Thread.sleep(ms);
	                        PreparedStatement ps = conn.prepareStatement("UPDATE TOTALCASES SET NumCases = ?");
	                        ps.setInt(1,ActualCases);
	                        ps.executeUpdate();
	                        conn.commit();
	                        
	                        // Uncomment 3 lines below to disable transactions
	                        
	                        /*PreparedStatement ps = conn.prepareStatement ("UPDATE TOTALCASES SET NumCases = ?");
	                        ps.setInt(1, server.TotalCases);
	                		ps.executeUpdate();*/
	                        
	                        if (server.TotalCases%1000 == 0) {
	                        	System.out.println("Notification: Over " + String.valueOf(server.TotalCases) + " cases have been reported");
	                        }
	                    	toreturn = "A new case has been introduced. There are currently " + String.valueOf(numCases) + " case(s).";
	                    	if (numCases >= 100000) {
	                    		System.out.println("Closing connection with a hospital.");
	                    		this.dis.close();
	                    		this.dos.close();
	                    		this.s.close();
	                    		break;
	                    	}
	                    	dos.writeUTF(toreturn);
	                		
	                    /*default:
	                    	dos.writeUTF("Invalid input");
	                        break;*/
	                	}
	            }
	            catch (Exception e){
	            	try {
						this.dis.close();
						this.dos.close();
		            	this.s.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}	
	            }
	                /*if(received.equals("Exit"))
	                { 
	                    System.out.println("Client " + this.s + " sends exit...");
	                    System.out.println("Closing this connection.");
	                    this.s.close();
	                    System.out.println("Connection closed");
	                    break;
	                }
	                if (received.equals("New Case!")) {
	                	NumCases = NumCases + 1;
	                	if (NumCases > 100000) {
	                		toreturn = "The maximum number of cases has been reached. Closing connection.";
	                		this.s.close();
	                		System.out.println("Maximum number of cases reached. Connection closed.");
	                		break;
	                	}
	                	toreturn = "A new case has been introduced. There are currently " + String.valueOf(NumCases) + " case(s).";
	                	dos.writeUTF(toreturn);
	                }
	            }*/  
	        /*try {
		        // closing resources
		        this.dis.close();
		        this.dos.close();
	        }*/
	        /*catch(IOException | SQLException e){
	            e.printStackTrace();
	        }*/
	    }
	}
}
